import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class EmpPanel extends JPanel implements ActionListener
{
	JButton b1,b2;
	Empinfo empinfo;
	Partinfo partinfo;

	JPanel p1=new JPanel(),
           p2=new JPanel(),
           p3=new JPanel();
		   
    static JPanel pCenter=new JPanel();
	static CardLayout card=new CardLayout();
	EmpPanel(MyFrame f)
	{
		JTextField text = new JTextField(15);
		
		setLayout(new BorderLayout());
		p3.setLayout(new BorderLayout());
		pCenter.setLayout(card);
		String abc = text.getText();
		JLabel label=new JLabel("Ա����Ϣ��ѯϵͳ");
		label.setFont(new Font("TimesRoman",Font.BOLD,24));
		p1.add(label);

		b1=new JButton("  ��  ��  ��  Ϣ  ");
		b2=new JButton("  ��������  ");

		b1.addActionListener(this);
		b2.addActionListener(this);

		p2.add(b1);
		p2.add(b2);


		empinfo=new Empinfo(f);
		partinfo = new Partinfo(f);

		pCenter.add("������Ϣ",empinfo);
		pCenter.add("��������",partinfo);

		p3.add(p2,BorderLayout.NORTH);
		
		p3.add(pCenter,BorderLayout.CENTER);
	    
		add(p1,BorderLayout.NORTH);
		add(p3,BorderLayout.CENTER);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
			card.show(pCenter, "������Ϣ");
		if(e.getSource()==b2)
			card.show(pCenter, "��������");

	}
}
