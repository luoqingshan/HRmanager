import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Empinfo extends JPanel implements ActionListener
{
	static JLabel jid,jname,jsex,jMari,jclass;
	JButton b;
	ModifyPassword modify;
	Empinfo(MyFrame f)
	{
		setLayout(new BorderLayout());
		modify=new ModifyPassword(f,"�޸�����",true);
		
		jid=new JLabel();
		jname=new JLabel();
		jsex=new JLabel();
		jMari=new JLabel();
		jclass=new JLabel();
		
		JPanel p=new JPanel();
		b=new JButton("�޸�����");
		b.addActionListener(this);
		p.add(b);
		add(p,BorderLayout.SOUTH);
		initInstance(this);
	}
	private void initInstance(Object obj)
	{
		Box base=Box.createHorizontalBox();
		Box left=Box.createVerticalBox();
		Box right=Box.createVerticalBox();
		JPanel p11=new JPanel(),
		       p12=new JPanel(),
		       p13=new JPanel(),
		       p14=new JPanel(),
		       p15=new JPanel();
		       
		JPanel p21=new JPanel(),
	           p22=new JPanel(),
	           p23=new JPanel(),
	           p24=new JPanel(),
	           p25=new JPanel();
	    
		p11.add(new JLabel("Ա����ţ�"));
		p21.add(jid);
		p12.add(new JLabel("Ա��������"));
		p22.add(jname);
		p13.add(new JLabel("Ա���Ա�"));
		p23.add(jsex);
		p14.add(new JLabel("�Ƿ��ѻ飺"));
		p24.add(jMari);
		p15.add(new JLabel("Ա��ѧ����"));
		p25.add(jclass);
		
		left.add(Box.createVerticalStrut(30));
		left.add(p11);
		left.add(Box.createVerticalStrut(10));
		left.add(p12);
		left.add(Box.createVerticalStrut(10));
		left.add(p13);
		left.add(Box.createVerticalStrut(10));
		left.add(p14);
		left.add(Box.createVerticalStrut(10));
		left.add(p15);
		left.add(Box.createVerticalStrut(10));
		
		right.add(Box.createVerticalStrut(30));
		right.add(p21);
		right.add(Box.createVerticalStrut(10));
		right.add(p22);
		right.add(Box.createVerticalStrut(10));
		right.add(p23);
		right.add(Box.createVerticalStrut(10));
		right.add(p24);
		right.add(Box.createVerticalStrut(10));
		right.add(p25);
		right.add(Box.createVerticalStrut(10));
		
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(left);
		base.add(right);
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		base.add(new JPanel());
		this.add(base,BorderLayout.CENTER);
	}
	public void actionPerformed(ActionEvent e)
	{
		modify.setVisible(true);
	}
	public static void saveStu(String id)
	{
		SqlManager DBm=SqlManager.createInstance();
		DBm.connectDB();
		String sql="exec ProcEmployee'"+id+"'";
		ResultSet rs=DBm.executeQuery(sql);
		System.out.println(sql);
		try{
			rs.next();
			jid.setText(rs.getString(1));
			jname.setText(rs.getString(2));
			jsex.setText(rs.getString(3));
			jMari.setText(rs.getString(4));
			jclass.setText(rs.getString(5));
			
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
